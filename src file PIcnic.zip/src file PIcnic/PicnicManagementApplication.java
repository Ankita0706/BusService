package com.cg.pcm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PicnicManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(PicnicManagementApplication.class, args);
		System.out.println("It Works!!");
	}

}
