package com.cg.pcm.controller;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.pcm.entity.BookingDetails;
import com.cg.pcm.entity.Place;
import com.cg.pcm.entity.User;
import com.cg.pcm.service.IPcmService;

@RestController
public class PicnicController {
	
	@Autowired
	IPcmService service;
	
	@PostMapping("/register")
	public User register(@RequestBody User usr) {
		System.out.println("usr");
		return service.register(usr);
	}
	
	@PostMapping("/login")
	public User Login(@RequestBody User usr) {
		System.out.println(usr.toString());
		return null;//service.login(usr);
	}
	
	@PostMapping("/addPlace")
	public Place addPlace(@RequestBody Place plc) {
		System.out.println(plc.toString());
		return service.addPlace(plc);
	}
	
	@GetMapping("/place/{type}")
	public Set<Place> findByType(@PathVariable String type) {
		return service.findByType(type);
	}

	@PostMapping("/booking")
	public BookingDetails booking(@RequestBody BookingDetails bk) {
		return service.booking(bk);
	}
	
	@GetMapping("/getallbooking")
	public Set<BookingDetails> findAllBooking() {
		return service.findAllBooking();
	}

}
