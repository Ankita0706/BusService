package com.cg.pcm.service;

import java.util.Set;

import com.cg.pcm.entity.BookingDetails;
import com.cg.pcm.entity.Place;
import com.cg.pcm.entity.User;

public interface IPcmService {
	public User register(User usr);
	public User login(User usr);
	public Place addPlace(Place place);
	public BookingDetails booking(BookingDetails bk);
	public Set<BookingDetails> findAllBooking();
	Set<Place> findByType(String type);
}
