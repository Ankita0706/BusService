package com.cg.pcm.service;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.pcm.entity.BookingDetails;
import com.cg.pcm.entity.Place;
import com.cg.pcm.entity.User;
import com.cg.pcm.repository.IPcmDao;
import com.sun.org.apache.xml.internal.security.exceptions.Base64DecodingException;
import com.sun.org.apache.xml.internal.security.utils.Base64;

@Transactional
@Service
public class PcmService implements IPcmService{
	
	@PersistenceContext
	EntityManager em;
	
	@Autowired
	IPcmDao dao;
	
	@Override
	public User register(User usr) {
		if(dao.findUser(usr.getuEmail()) != null) {
			throw new RuntimeException("E-mail already exists.");
		}
		Set<BookingDetails> bkSet = new HashSet<>();
		usr.setBk(bkSet);
		return dao.register(usr);
	}

	@Override
	public User login(User usr) {
		User user = dao.login(usr);
		if(user.equals(null)) {
			throw new RuntimeException("User does not exist.");
		}
		if(!usr.getuPassword().equals(user.getuPassword())) {
			throw new RuntimeException("Password does not match");
		}
			else {
				System.out.println("Login done");
			}
		return user;
	}

	@Override
	public Place addPlace(Place place) {
		TypedQuery<Place> query=em.createQuery("select plc from Place plc where plc.pName=:name",Place.class);
		query.setParameter("name",place.getpName());
//		if(query.getSingleResult() != null) {
//			throw new RuntimeException("Place already exists");
//		}
		
		Set<BookingDetails> bkSet = new HashSet<>();
		place.setBkSetPl(bkSet);
		return dao.addPlace(place);
	}

	@Override
	public Set<Place> findByType(String type) {
		if(type.equals("summer-season") || type.equals("winter-season") || type.equals("rainy-season")) {
			return dao.findBySeason(type);
		}
		else {
			return dao.findByCategory(type);
		}
	}

	@Override
	public BookingDetails booking(BookingDetails bk) {
		return dao.booking(bk);
	}

	@Override
	public Set<BookingDetails> findAllBooking() {
		return dao.findAllBooking();
	}

}
