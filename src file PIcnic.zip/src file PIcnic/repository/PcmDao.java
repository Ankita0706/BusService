package com.cg.pcm.repository;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.pcm.entity.BookingDetails;
import com.cg.pcm.entity.Place;
import com.cg.pcm.entity.User;

@Repository
public class PcmDao implements IPcmDao{
	
	@PersistenceContext
	EntityManager em;
	
	@Override
	public User findUser(String userName) {
		return em.find(User.class, userName);
	}
	
	@Override
	public Place findPlace(Integer pId) {
		return em.find(Place.class, pId);
	}

	@Override
	public BookingDetails findBk(Integer bId) {
		return em.find(BookingDetails.class, bId);
	}

	@Override
	public User register(User usr) {
		em.persist(usr);
		return usr;
	}

	@Override
	public User login(User usr) {
		User user = findUser(usr.getuEmail());
		return user;
	}

	@Override
	public Place addPlace(Place place) {
		em.persist(place);
		return place;
	}

	@Override
	public Set<Place> findBySeason(String season) {
		TypedQuery< Place> query=em.createQuery("select plc from Place plc where plc.pSeason=:seasn",Place.class);
		query.setParameter("seasn",season);
		Set<Place> placeSet = new HashSet<>(query.getResultList());
		return placeSet;
	}

	@Override
	public Set<Place> findByType(String season) {
		TypedQuery< Place> query=em.createQuery("select plc from Place plc where plc.pSeason=:seasn",Place.class);
		query.setParameter("seasn",season);
		Set<Place> placeSet = new HashSet<>(query.getResultList());
		return placeSet;
	}

	
	@Override
	public Set<Place> findByCategory(String cat) {
		TypedQuery<Place> query=em.createQuery("select plc from Place plc where plc.pCategory=:cate",Place.class);
		query.setParameter("cate",cat);
		Set<Place> placeSet = new HashSet<>(query.getResultList());
		return placeSet;
	}

	@Override
	public BookingDetails booking(BookingDetails bk) {
		em.persist(bk);
		return bk;
	}

	@Override
	public Set<BookingDetails> findAllBooking() {
		TypedQuery<BookingDetails> query=em.createQuery("select bk from BookingDetails bk",BookingDetails.class);
		
		System.out.println(query.getResultList().size());
		Set<BookingDetails> bk = new HashSet<>(query.getResultList());
		return bk;
	}

}
