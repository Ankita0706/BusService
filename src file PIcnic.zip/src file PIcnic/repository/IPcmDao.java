package com.cg.pcm.repository;

import java.util.Set;

import com.cg.pcm.entity.BookingDetails;
import com.cg.pcm.entity.Place;
import com.cg.pcm.entity.User;

public interface IPcmDao {
	
	public User findUser(String userName);
	public Place findPlace(Integer pId);
	public BookingDetails findBk(Integer bId);
	public User register(User usr);
	public User login(User usr);
	public Place addPlace(Place place);
	public Set<Place> findBySeason(String season);
	public BookingDetails booking(BookingDetails bk);
	public Set<BookingDetails> findAllBooking();
	public Set<Place> findByCategory(String cat);
	Set<Place> findByType(String season);
}
