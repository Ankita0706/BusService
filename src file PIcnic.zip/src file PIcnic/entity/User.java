package com.cg.pcm.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="user_tbl")
public class User {
	
	@Id
	private String uEmail;
	private String uName;
	private String uPassword;
	private String uMobile;
	private String uAddress;
	@OneToMany(mappedBy="user",cascade=CascadeType.ALL)
	private Set<BookingDetails> bkSetUsr;
		
	@Override
	public String toString() {
		return "User [uEmail=" + uEmail + ", uName=" + uName + ", uPassword=" + uPassword + ", uMobile=" + uMobile
				+ ", uAddress=" + uAddress + ", bkSetUsr=" + bkSetUsr + "]";
	}
	public String getuEmail() {
		return uEmail;
	}
	public void setuEmail(String uEmail) {
		this.uEmail = uEmail;
	}
	public String getuName() {
		return uName;
	}
	public void setuName(String uName) {
		this.uName = uName;
	}
	public String getuPassword() {
		return uPassword;
	}
	public void setuPassword(String uPassword) {
		this.uPassword = uPassword;
	}
	public String getuMobile() {
		return uMobile;
	}
	public void setuMobile(String uMobile) {
		this.uMobile = uMobile;
	}
	public String getuAddress() {
		return uAddress;
	}
	public void setuAddress(String uAddress) {
		this.uAddress = uAddress;
	}
	public Set<BookingDetails> getBk() {
		return bkSetUsr;
	}
	public void setBk(Set<BookingDetails> bk) {
		this.bkSetUsr = bk;
	}

	
}
