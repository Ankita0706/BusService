package com.cg.pcm.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="place_tbl")
@SequenceGenerator(name="seq3", initialValue=1, allocationSize=1)
public class Place {
	
	@Id
	@GeneratedValue(strategy= GenerationType.SEQUENCE, generator="seq3")
	private Integer pId;
	private String pName;
	private String pCategory;
	private String pSeason;
	@ElementCollection
	private Set<String> pImages;
	private String pDescription;
	private Integer pPrice;
	private Integer pAvailableSeats;
	@OneToMany(mappedBy="plc",cascade=CascadeType.ALL)
	private Set<BookingDetails> bkSetPl;
	
	public Integer getpId() {
		return pId;
	}
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	public String getpCategory() {
		return pCategory;
	}
	public void setpCategory(String pCategory) {
		this.pCategory = pCategory;
	}
	public String getpSeason() {
		return pSeason;
	}
	public void setpSeason(String pSeason) {
		this.pSeason = pSeason;
	}
	public Set<String> getpImages() {
		return pImages;
	}
	public void setpImages(Set<String> pImages) {
		this.pImages = pImages;
	}
	public String getpDescription() {
		return pDescription;
	}
	public void setpDescription(String pDescription) {
		this.pDescription = pDescription;
	}
	public Integer getpPrice() {
		return pPrice;
	}
	public void setpPrice(Integer pPrice) {
		this.pPrice = pPrice;
	}
	public Integer getpAvailableSeats() {
		return pAvailableSeats;
	}
	public void setpAvailableSeats(Integer pAvailableSeats) {
		this.pAvailableSeats = pAvailableSeats;
	}
	public Set<BookingDetails> getBkSetPl() {
		return bkSetPl;
	}
	public void setBkSetPl(Set<BookingDetails> bkSetPl) {
		this.bkSetPl = bkSetPl;
	}
	
	
}
