package com.cg.pcm.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="booking_tbl")
@SequenceGenerator(name="seq1", initialValue=1, allocationSize=1)
public class BookingDetails {
	
	@Id
	@GeneratedValue(strategy= GenerationType.SEQUENCE, generator="seq1")
	private Integer bId;
//	@OneToMany(cascade=CascadeType.ALL)
//	@ElementCollection
//	private Set<Traveller> travellerSet;
	private String firstName;
	private String lastname;
	private String idType;
	private String idNumber;
	private String contactNo;
	private String altContactNo;
	private Integer seatNo;
	@ManyToOne(cascade=CascadeType.MERGE)
	@JoinColumn(name="user_id")
	private User user;
	@ManyToOne(cascade=CascadeType.MERGE,targetEntity=Place.class)
	@JoinColumn(name="place_id")
	private Place plc;
	public Integer getbId() {
		return bId;
	}
//	public Set<Traveller> getTravellerSet() {
//		return travellerSet;
//	}
//	public void setTravellerSet(Set<Traveller> travellerSet) {
//		this.travellerSet = travellerSet;
//	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	public String getAltContactNo() {
		return altContactNo;
	}
	public void setAltContactNo(String altContactNo) {
		this.altContactNo = altContactNo;
	}
	public Integer getSeatNo() {
		return seatNo;
	}
	public void setSeatNo(Integer seatNo) {
		this.seatNo = seatNo;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Place getPlc() {
		return plc;
	}
	public void setPlc(Place plc) {
		this.plc = plc;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getIdType() {
		return idType;
	}
	public void setIdType(String idType) {
		this.idType = idType;
	}
	public String getIdNumber() {
		return idNumber;
	}
	public void setIdNumber(String idNumber) {
		this.idNumber = idNumber;
	}
	
}
