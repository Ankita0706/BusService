import { Component, OnInit, OnChanges, SimpleChanges } from '@angular/core';
import { LoginAuthServiceService } from 'src/app/Service/login-auth-service.service';
import { LoginService } from 'src/app/Service/loginService';
import { AdminAuthServiceService } from 'src/app/Service/admin-auth-service.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-header-component',
  templateUrl: './header-component.component.html',
  styleUrls: ['./header-component.component.css']
})
export class HeaderComponentComponent implements OnInit{
  isAdmin:boolean;
  adminArray:string[];
  url;
  constructor(private loginAuthService:LoginAuthServiceService,
              private adminAuthService:AdminAuthServiceService,
              private router:Router,
              private route:ActivatedRoute) { }

  ngOnInit() {
    this.isAdmin = this.adminAuthService.checkAdmin();
    this.url = this.router.url
  }

  onSignOut(){
    this.isAdmin = false;
    this.loginAuthService.onSignOut();
   // this.router.navigate[('signIn')];
  }

  onAddPlace(){
    this.router.navigate(['addplace'],{relativeTo:this.route})
  }

  onSeeBookings(){
    this.router.navigate(['seebookings'],{relativeTo:this.route})
  }
}
