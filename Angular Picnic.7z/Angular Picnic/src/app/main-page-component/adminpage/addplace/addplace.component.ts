import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { PlaceService } from 'src/app/Service/place.service';
import { Place } from 'src/app/Service/app.place';

@Component({
  selector: 'app-addplace',
  templateUrl: './addplace.component.html',
  styleUrls: ['./addplace.component.css']
})
export class AddplaceComponent implements OnInit {
  placeData:Place;
  addPlaceForm:FormGroup;
  imgArray=[];
  url: string;
  imgSrc:string='';
  constructor(private placeService:PlaceService) { }

  ngOnInit() {
    this.addPlaceForm = new FormGroup({
      'pName': new FormControl(null,[Validators.required]),
      'pSeason': new FormControl(null,[Validators.required]),
      'pCategory':new FormControl(null,[Validators.required]),
      'pAvailableSeats':new FormControl(null,[Validators.required]),
      'pPrice':new FormControl(null,[Validators.required]),
      'pDescription':new FormControl(null,[Validators.required]),
     // 'pImage':new FormControl(null,[Validators.required])
    })
  }
  
  readUrl(event:any) {
    console.log(event)
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();
  
      reader.onload = (event: ProgressEvent) => {
        this.url = <string> (<FileReader>event.target).result;
       console.log(this.url)
       this.imgSrc=this.url;
       this.imgArray.push(this.url);
      }
  
      reader.readAsDataURL(event.target.files[0]);
    }
  }

  onAddPlace(){
    let pName:string = this.addPlaceForm.value.pName ;
    let pSeason:string = this.addPlaceForm.value.pSeason;
    let pType:string = this.addPlaceForm.value.pCategory;
    let pImages:string[] = this.imgArray;
    let pSeat:number = +this.addPlaceForm.value.pAvailableSeats;
    let pCost:number = +this.addPlaceForm.value.pPrice;
    let pDescription = this.addPlaceForm.value.pDescription;
    console.log(this.addPlaceForm)
    this.placeData = new Place(null,pName,pSeason,pType,pImages,pSeat,pCost,pDescription);
    this.placeService.onAddPlace(this.placeData).subscribe(
      (data:Place)=> {alert('Place Added Successfully')
                console.log(data.pName)},
      (error) => console.log("Some error occured"),
      () => console.log('Action completed')
    );
  }

}
