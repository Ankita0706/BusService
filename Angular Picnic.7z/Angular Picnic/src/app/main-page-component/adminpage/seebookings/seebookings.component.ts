import { Component, OnInit } from '@angular/core';
import { BookingDetals } from 'src/app/Service/app.bookingdetails';
import { ActivatedRoute, Router } from '@angular/router';
import { PlaceService } from 'src/app/Service/place.service';

@Component({
  selector: 'app-seebookings',
  templateUrl: './seebookings.component.html',
  styleUrls: ['./seebookings.component.css']
})
export class SeebookingsComponent implements OnInit {
  bookingList:number[]=[1,2,3,4,5,6,7,8,9]

  public allbooking;
  constructor(private route:ActivatedRoute,
    private placeService:PlaceService,
    private router:Router) { }
  
  ngOnInit() {
    this.getbookings();

  }

  getbookings(){
    this.placeService.getBookingList().subscribe(
      data=>{this.allbooking=data;
      console.log(data)
      },
      error=>console.log(error),
      ()=>console.log('loading complete')
    )
  }

  

}
