import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminpage',
  templateUrl: './adminpage.component.html',
  styleUrls: ['./adminpage.component.css']
})
export class AdminpageComponent implements OnInit {

  imgArray=[];
  url: string;

  constructor() { }

  ngOnInit() {
  }

  Logo:string;

  handleUpload(e):void{
     this.Logo = e.target.value;
 
  }
  

  onFileSelected(event){
    console.log(event)
  }

  readUrl(event:any) {
    console.log(event)
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();
  
      reader.onload = (event: ProgressEvent) => {
        this.url = <string> (<FileReader>event.target).result;
       console.log(this.url)
       this.imgArray.push(this.url);
        
      }
  
      reader.readAsDataURL(event.target.files[0]);
    }
  }

}
