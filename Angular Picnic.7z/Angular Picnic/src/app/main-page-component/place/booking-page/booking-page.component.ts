import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Place } from 'src/app/Service/app.place';
import { PlaceService } from 'src/app/Service/place.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { LoginService } from 'src/app/Service/loginService';
import { User } from 'src/app/Service/app.User';
import { BookingDetals } from 'src/app/Service/app.bookingdetails';

@Component({
  selector: 'app-booking-page',
  templateUrl: './booking-page.component.html',
  styleUrls: ['./booking-page.component.css']
})
export class BookingPageComponent implements OnInit {
  place:Place;
  type:string;
  msg:string='';
  seatCount:number=7;
  count:number;
  arr:number[]=[];
  bDetails:BookingDetals;

  constructor(private route:ActivatedRoute,private placeService:PlaceService,private loginService:LoginService) { }
  bookingForm:FormGroup;
  ngOnInit() {
    this.route.params.subscribe(
      (param) => {
        console.log(param.index)
        this.place = this.placeService.getPlace(param.index)
      }
    )

    this.bookingForm = new FormGroup({
      'fName': new FormControl(null,[Validators.required]),
      'lName': new FormControl(null,[Validators.required]),
      'contactNumer': new FormControl(null,[Validators.required]),
      'altContactNumber': new FormControl(null,[Validators.required]),
      'idProof': new FormControl(null,[Validators.required]),
      'idProofNum': new FormControl(null,[Validators.required]),
      'date': new FormControl(null,[Validators.required]),
      'seatCount': new FormControl(null,[Validators.required]),
    })  

  }

  onSubmit(){
    const bId:string = null;
    const user:User = this.loginService.userdata;
    const plc:Place = this.placeService.place;
    const firstName:string = this.bookingForm.value.fName;
    const lastName:string = this.bookingForm.value.lname
    const contactNo:string= this.bookingForm.value.contactNumer;
    const altContactNo:string= this.bookingForm.value.altContactNumber;
    const idType:string= this.bookingForm.value.idProof;
    const idNumber:string= this.bookingForm.value.idProofNum;
    //date:string;
    const seatNo:number = this.bookingForm.value.seatCount;
    
    this.bDetails  = new BookingDetals(bId,user,plc,firstName,lastName,contactNo,altContactNo,idNumber,idType,seatNo);
    console.log(this.bookingForm.value)
    this.placeService.addBooking(this.bDetails).subscribe(
      (data) => alert('Booking Successful')
    )
    this.msg="Details submitted succesfully"
    console.log(this.msg)
  }

}
