import { Component, OnInit } from '@angular/core';
import { Place } from 'src/app/Service/app.place';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { PlaceService } from 'src/app/Service/place.service';

@Component({
  selector: 'app-place-detail-component',
  templateUrl: './place-detail-component.component.html',
  styleUrls: ['./place-detail-component.component.css']
})
export class PlaceDetailComponentComponent implements OnInit {
  place:Place;
  index:number;
  constructor(private route:ActivatedRoute,
              private placeService:PlaceService,
              private router:Router) { }

  ngOnInit() {
    this.route.params.subscribe(
      (para:Params) => {
        this.index = para['index'];
        this.place = this.placeService.getPlace(this.index);
        this.placeService.place = this.place;
        console.log(this.index)
      }
    )
  }

  onClick(){
    this.router.navigate(['bookingPage'],{relativeTo:this.route})
  }

}
