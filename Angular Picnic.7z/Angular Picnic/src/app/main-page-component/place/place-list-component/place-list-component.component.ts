import { Component, OnInit } from '@angular/core';
import { Place } from 'src/app/Service/app.place';
import { PlaceService } from 'src/app/Service/place.service';

@Component({
  selector: 'app-place-list-component',
  templateUrl: './place-list-component.component.html',
  styleUrls: ['./place-list-component.component.css']
})
export class PlaceListComponentComponent implements OnInit {
  
  placeList;
  
  constructor(private placeService:PlaceService) { }

  ngOnInit() {
    
    this.placeService.getPlaceList().subscribe(
      (data:Place[]) => {
        console.log(data[0].pName+'in placelist')
        this.placeList = data;
        this.placeService.placeList = data
        console.log(this.placeService.placeList[0])
      },
      (error) => console.log('Error Occured'),
      () => console.log('Place list loaded')
    );
  }
}
