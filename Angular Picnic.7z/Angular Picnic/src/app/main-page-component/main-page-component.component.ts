import { Component, OnInit } from '@angular/core';
import { PlaceService } from '../Service/place.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-main-page-component',
  templateUrl: './main-page-component.component.html',
  styleUrls: ['./main-page-component.component.css']
})
export class MainPageComponentComponent implements OnInit {

  constructor(private placeService:PlaceService,private router:Router) { }

  ngOnInit() {
  }
  
  onCardSelect(cardName:string)
  {
    this.placeService.setCardType(cardName)
    this.router.navigate(['place'])
  }

}
