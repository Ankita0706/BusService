import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-things-to-carry-component',
  templateUrl: './things-to-carry-component.component.html',
  styleUrls: ['./things-to-carry-component.component.css']
})
export class ThingsToCarryComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
