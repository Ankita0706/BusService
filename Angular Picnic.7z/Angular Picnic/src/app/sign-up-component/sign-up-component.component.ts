import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../Service/app.User';
import { LoginService } from '../Service/loginService';
import { FormGroup, FormControl, Validators } from '@angular/forms';


@Component({
  selector: 'app-sign-up-component',
  templateUrl: './sign-up-component.component.html',
  styleUrls: ['./sign-up-component.component.css']
})
export class SignUpComponentComponent implements OnInit {

  name;
  email;
  password;
  mobileNumber;
  user:User[];
  userElement:User;
  
  signupForm:FormGroup;
  constructor(private router: Router,private loginService:LoginService) { }

  ngOnInit() {
    this.signupForm = new FormGroup({
      'uName': new FormControl(null,[Validators.required,,Validators.pattern('[A-Za-z]{1,}')]),
      'uEmail': new FormControl(null,[Validators.email,Validators.required]),
      'uPassword': new FormControl(null,[Validators.required,Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}')]),
      'uMobile': new FormControl(null,[Validators.required,Validators.pattern('[789][0-9]{9}')]),
      'uAddress': new FormControl(null,[Validators.required,Validators.pattern('[A-Za-z]{1,}')]) 
    });
  }

  
  goToSignIn()
  {
    this.router.navigate(['signIn'])
  }
   
 

  signUp()
  {
      console.log(this.signupForm.value)
      console.log(this.signupForm)
    
      // this.user=[
      //   new User(this.name,this.email,this.password,this.mobileNumber)
      // ];
  
      // for(let element of this.user)
      // {
      //   this.userElement = element;
      // }
  
       this.loginService.addUser(this.signupForm.value).subscribe(
         (data:User)=>{  
            console.log(alert('Registration successful'))
          },
         (error)=> console.log("Error occured"),
         ()=>console.log('Action completed')
       );
      // console.log(this.name+" "+this.email+" "+this.password+" "+this.mobileNumber)
       this.router.navigate(['signIn'])
    
    
  }

}
