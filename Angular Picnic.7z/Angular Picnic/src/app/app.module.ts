import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { StartComponentComponent } from './start-component/start-component.component';
import { SignInComponentComponent } from './sign-in-component/sign-in-component.component';
import { SignUpComponentComponent } from './sign-up-component/sign-up-component.component';
import { MainPageComponentComponent } from './main-page-component/main-page-component.component';
import { PlaceListComponentComponent } from './main-page-component/place/place-list-component/place-list-component.component';
import { PlaceDetailComponentComponent } from './main-page-component/place/place-detail-component/place-detail-component.component';
import { ThingsToCarryComponentComponent } from './main-page-component/things-to-carry-component/things-to-carry-component.component';
import { HeaderComponentComponent } from './main-page-component/header-component/header-component.component';
import { StarterpageComponent } from './main-page-component/place/starterpage/starterpage.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms'
import { PlaceComponent } from './main-page-component/place/place.component';
import { PlaceItemComponent } from './main-page-component/place/place-list-component/place-item/place-item.component';
import { LoginService } from './Service/loginService';
import { PlaceService } from './Service/place.service';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { BookingPageComponent } from './main-page-component/place/booking-page/booking-page.component';
import { AdminpageComponent } from './main-page-component/adminpage/adminpage.component';
import { HttpClientModule } from '@angular/common/http'
import { from } from 'rxjs';
import { SeebookingsComponent } from './main-page-component/adminpage/seebookings/seebookings.component';
import { AddplaceComponent } from './main-page-component/adminpage/addplace/addplace.component';

@NgModule({
  declarations: [
    AppComponent,
    StartComponentComponent,
    SignInComponentComponent,
    SignUpComponentComponent,
    MainPageComponentComponent,
    PlaceListComponentComponent,
    PlaceDetailComponentComponent,
    ThingsToCarryComponentComponent,
    HeaderComponentComponent,
    StarterpageComponent,
    PlaceComponent,
    PlaceItemComponent,
    PageNotFoundComponent,
    BookingPageComponent,
    AdminpageComponent,
    AddplaceComponent,
    SeebookingsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [LoginService,PlaceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
