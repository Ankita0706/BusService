import { Component, OnInit, ErrorHandler } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../Service/loginService';
import { User } from '../Service/app.User';
import { LoginAuthServiceService } from '../Service/login-auth-service.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { error } from 'protractor';
import { AdminAuthServiceService } from '../Service/admin-auth-service.service';

@Component({
  selector: 'app-sign-in-component',
  templateUrl: './sign-in-component.component.html',
  styleUrls: ['./sign-in-component.component.css']
})
export class SignInComponentComponent implements OnInit {

  signinForm:FormGroup;
  uEmail;
  uPassword;
  udata:User;
  constructor(private router: Router,
              private loginService:LoginService,
              private loginAuthService:LoginAuthServiceService,
              private adminservice:AdminAuthServiceService) { }

  ngOnInit() {
    this.signinForm = new FormGroup({
      'uEmail' : new FormControl(null,[Validators.required,Validators.email]),
      'uPassword' : new FormControl(null,[Validators.required,Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}')])
    })
  }

  

  goToSignUp(){
    this.router.navigate(['signup'])
  }

  validate(){

    console.log(this.signinForm.value.uPassword)
    console.log(this.signinForm.value.uEmail)
    
    var email = this.signinForm.value.uEmail;
    var password = this.signinForm.value.uPassword;

    this.udata = new User('a',email,password,'aa','a')
    this.loginService.getUser(this.udata).subscribe(
      (data:User) => {
       console.log(data.uName+" "+data.uEmail+" called")
       console.log(data)
        this.loginService.userdata = data
        alert('Login Successful');
        this.loginAuthService.onSignin();
        console.log(this.adminservice.canActivate());
       
        if(this.adminservice.canActivate()==true){
          
          this.router.navigate(['admin'])
        }
         else{
          this.router.navigate(['main']);
         }
        
        console.log(this.loginService.userdata.uName)
      },
      (error:ErrorEvent) => console.log("error occured"+error.filename),
      ()=>{ 
        console.log('Action completed')
      }
    )
    // this.udata.uEmail = this.signinForm.value.uEmail;
    // this.udata.uPassword = this.signinForm.value.uPassword;
    
  //   this.loginService.getUser(this.udata).subscribe(
  //     (data:User) => this.loginService.userdata = data,
  //     error => alert('some error occured'),
  //     () => alert('Action completed')
  //   )

  //   if(this.loginService.userdata === null)
  //   {
  //     alert("Invalid username");
  //   }
  //   else
  //   {
  //       if(this.loginService.userdata.uPassword === this.signinForm.value.uPassword){
  //           this.loginAuthService.onSignin();
  //           this.router.navigate(['main'])
  //       }
  //       else{
  //           alert("Invalid password")
  //       }
  //   }
   
   }
  }


