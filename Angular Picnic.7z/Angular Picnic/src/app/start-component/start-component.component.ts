import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-start-component',
  templateUrl: './start-component.component.html',
  styleUrls: ['./start-component.component.css']
})
export class StartComponentComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit() {
  }

  goToSignin(){
    this.router.navigate(['signIn']);
  }

}
