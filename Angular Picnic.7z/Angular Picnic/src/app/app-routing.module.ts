import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { StartComponentComponent } from './start-component/start-component.component';
import { SignInComponentComponent } from './sign-in-component/sign-in-component.component';
import { SignUpComponentComponent } from './sign-up-component/sign-up-component.component';
import { MainPageComponentComponent } from './main-page-component/main-page-component.component';
import { StarterpageComponent } from './main-page-component/place/starterpage/starterpage.component';
import { PlaceDetailComponentComponent } from './main-page-component/place/place-detail-component/place-detail-component.component';
import { ThingsToCarryComponentComponent } from './main-page-component/things-to-carry-component/things-to-carry-component.component';
import { PlaceComponent } from './main-page-component/place/place.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { BookingPageComponent } from './main-page-component/place/booking-page/booking-page.component';
import { LoginAuthServiceService } from './Service/login-auth-service.service';
import { AdminpageComponent } from './main-page-component/adminpage/adminpage.component';
import { AdminAuthServiceService } from './Service/admin-auth-service.service';
import { AddplaceComponent } from './main-page-component/adminpage/addplace/addplace.component';
import { SeebookingsComponent } from './main-page-component/adminpage/seebookings/seebookings.component';



const routes: Routes = [
  {path:'',redirectTo:'/start',pathMatch:'full'},
  {path:'start',component:StartComponentComponent},
  {path:'signIn',component:SignInComponentComponent},
  {path:'signup',component:SignUpComponentComponent},
  {path:'main',component:MainPageComponentComponent},
  {path:'admin',component:AdminpageComponent, children:[   //canActivate:[AdminAuthServiceService],
    {path:'',redirectTo:'/admin/addplace',pathMatch:'full'},
    {path:'addplace',component:AddplaceComponent},
    {path:'seebookings',component:SeebookingsComponent}
  ]},
  {path:'place',component:PlaceComponent,children:[
    {path:'',component:StarterpageComponent},
    {path:':index',component:PlaceDetailComponentComponent},
    {path:':index/bookingPage',component:BookingPageComponent}    //,canActivate:[LoginAuthServiceService]
  ]},
  {path:'**', component:PageNotFoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
