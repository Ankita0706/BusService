import { Place } from './app.place';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BookingDetals } from './app.bookingdetails';

const httpOptions = {
    headers:new HttpHeaders({'Content-Type':'application/json'})
};

@Injectable()
export class PlaceService{

     cardType:string;
     placeList:Place[];
     place:Place;
     constructor(private http:HttpClient){}
    
    onAddPlace(place:Place){
        console.log(place.pSeason)
        let body = JSON.stringify(place);
        console.log('BODY'+body)
        return this.http.post('server/addPlace',body,httpOptions)
    } //done

    getPlaceList(){
        console.log(this.cardType + " in get list")
        return this.http.get('server/place/'+this.cardType);
    }

    getBookingList(){
        console.log("in service");
        return this.http.get('server/getallbooking');
    }

    getPlace(index:number){
        return this.placeList[index];
    }

    setCardType(type:string){
        this.cardType = type;
        console.log('service '+this.cardType)
    }

    addBooking(bookingData:BookingDetals){
        console.log(bookingData.lastName)
        console.log(bookingData)
        let data = JSON.stringify(bookingData)
        console.log(data)
        return this.http.post('server/booking',data,httpOptions)
    }
}