import { User } from './app.User';
import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient, HttpErrorResponse } from '@angular/common/http';
import { BookingDetals } from './app.bookingdetails';
import { Observable } from 'rxjs';




const httpOptions = {
    headers:new HttpHeaders({'Content-Type':'application/json'})
};

@Injectable()
export class LoginService{
    constructor(private http:HttpClient){}
     users:User[]=[
    //     new User('Ankit','ankitkadam567@gmail.com','Ankit@123','1234567890','Chembur'),
    //     new User('Chetan','chetanwagadare123@gmail.com','Chetan@123','9874561230','Airoli'),
    //     new User('Ganesh','ganeshghogare@gmail.com','Ganesh@123','7588663860','Virar')
     ];

    userEmail:string;
    userdata:User;
    isAdmin:boolean=false;
    
    adminArray:string[] = ['ankitkadam567@gmail.com','chetanwagadare123@gmail.com','ganeshghogare@gmail.com']

    addUser(data:User){
       
        console.log(data.uName+" "+data.uEmail+" "+data.uPassword+" "+data.uMobile+" "+data.uAddress)
        let body = JSON.stringify(data);
        //this.users.push(data);
        //console.log(this.users);
        return this.http.post('server/register',body,httpOptions)
        

    }

    getUser(user:User):Observable<any>{
        console.log(user.uEmail+" "+user.uPassword+' service called')
        this.userdata=user;
        let usData = JSON.stringify(user)
        console.log(usData)
        return this.http.post('server/login',usData,httpOptions)
        
        
    }

    checkAdmin(){
              console.log("called")
              for(let email of this.adminArray){
                  if(email === 'chetanwagadare123@gmail.com')
                  {
                      console.log("true")
                      return true
                  }
              }
              console.log("false")
              return false;
          }
          

        //   private errorHandle(errorResponse:HttpErrorResponse){
        //       console.error(errorResponse)
        //       return new throwError('')
        //   }

    
}