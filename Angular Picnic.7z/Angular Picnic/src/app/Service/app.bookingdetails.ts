import { User } from './app.User';
import { Place } from './app.place';

export class BookingDetals{
    bId:string;//
    user:User;//
    plc:Place;//
    firstName:string;//
    lastName:string;//
    contactNo:string;//
    altContactNo:string;//
    idType:string;
    idNumber:string;
    //date:string;
    seatNo:number;//

    constructor(bId:string,user:User,plc:Place,firstName:string,lastName:string,contactNo:string,altContactNo:string,idType:string,idNumber:string,seatNo:number){
        this.bId=bId;
        this.user=user;
        this.plc=plc;
        this.firstName=firstName;
        this.lastName=lastName;
        this.contactNo=contactNo;
        this.altContactNo=altContactNo;
        this.idType=idType;
        this.idNumber=idNumber;
        this.seatNo=seatNo;
    }
    
}