import { Injectable } from '@angular/core';
import { LoginService } from './loginService';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AdminAuthServiceService {

  adminArray:string[] = ['ankitkadam567@gmail.com','chetanwagadare123@gmail.com','ganeshghogare@gmail.com']

  constructor(private loginService:LoginService,private router:Router) { }

  checkAdmin(){
        for(let email of this.adminArray){
            if(this.loginService.userdata.uEmail === email)
            {
                return true
            }
        }
        return false;
    }

  canActivate(){
    if(this.checkAdmin()){
      return true;
    }
    else{
      alert('only admin can visit this page.')
    }
  }


}
