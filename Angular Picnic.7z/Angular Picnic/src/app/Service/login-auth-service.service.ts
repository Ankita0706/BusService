import { Injectable } from '@angular/core';
import { CanActivate } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class LoginAuthServiceService implements CanActivate{

  constructor() { }
  loginStatus:boolean=false;

  onSignin(){
    this.loginStatus = true;
  }

  onSignOut(){
    this.loginStatus = false;
  }

  canActivate():boolean{
    if(this.loginStatus){
      return true;
    }
    else{
      alert("Please login first")
    }
  }

}
