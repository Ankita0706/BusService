import { Component } from '@angular/core';


export class User{

    uName:string;
    uEmail:string;
    uPassword:string;
    uMobile:string;
    uAddress:string;
    constructor(name:string,email:string,password:string,mobileNo:string,address:string){
        this.uName = name;
        this.uEmail = email;
        this.uPassword = password;
        this.uMobile = mobileNo;
        this.uAddress = address;
    }
     
}