export class Place{
  pId:number;
  pName:string;
  pSeason:string;
  pCategory:string;
  pImages:string[];
  pAvailableSeats:number;
  pPrice:number;
  pDescription:string;
    constructor(pId:number,pName:string,pSeason:string,pCategory:string,pImages:string[],pAvailableSeats:number,pPrice:number,pDescription:string){
      this.pId = pId;
      this.pName = pName;
      this.pSeason = pSeason;
      this.pCategory = pCategory;
      this.pImages = pImages;
      this.pAvailableSeats = pAvailableSeats;
      this.pPrice = pPrice;
      this.pDescription = pDescription
    }
}